# youtube-alexa-python

[![docker](https://github.com/unofficial-skills/youtube-alexa-python/actions/workflows/docker-package.yml/badge.svg)](https://github.com/unofficial-skills/youtube-alexa-python/actions/workflows/docker-package.yml)

[![Windows](https://github.com/unofficial-skills/youtube-alexa-python/actions/workflows/windows.yml/badge.svg)](https://github.com/unofficial-skills/youtube-alexa-python/actions/workflows/windows.yml)

[![Python](https://github.com/unofficial-skills/youtube-alexa-python/actions/workflows/python.yml/badge.svg)](https://github.com/unofficial-skills/youtube-alexa-python/actions/workflows/python.yml)

## Run in docker


docker run -d --restart unless-stopped --name youtube-alexa -p 5000:5000 andrewstech/youtube-alexa-python:python
